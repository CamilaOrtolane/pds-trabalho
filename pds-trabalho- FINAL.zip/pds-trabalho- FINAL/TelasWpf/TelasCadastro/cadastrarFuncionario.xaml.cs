﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TelasWpf.Models;
using TelasWpf.Database;
using TelasWpf.Helpers;
using TelasWpf.interfaces;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Common;

namespace TelasWpf.TelasCadastro
{
    /// <summary>
    /// Lógica interna para cadastrarFuncionario.xaml
    /// </summary>
    public partial class cadastrarFuncionario : Window
    {
        private int _id;
        private Funcionario _funcionario;
        public cadastrarFuncionario()
        {
            InitializeComponent();
            Loaded += CadastrarFuncionario_Loaded;
        }
        public cadastrarFuncionario(int id)
        {
            _id = id;
            InitializeComponent();
            Loaded += CadastrarFuncionario_Loaded;
        }

        private void CadastrarFuncionario_Loaded(object sender, RoutedEventArgs e)
        {
            _funcionario = new Funcionario();

            if( _id > 0)
            {
                FillForm();
            }

           
        }

        private void btnVoltar_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new MenuPrincipal();
            newWindow.Show();
            Close();
        }
        private void btnSalvar_Click(object sender, RoutedEventArgs e)
        {

     
                _funcionario.Nome = txtNome.Text;
                _funcionario.Telefone = txtTelefone.Text;
                _funcionario.Setor = txtSetor.Text;
                _funcionario.Rg = txtRg.Text;
                _funcionario.Funcao = txtFuncao.Text;
                _funcionario.EstadoCivil = txtEstCivi.Text;
                _funcionario.Estado = txtEstado.Text;
                _funcionario.Cpf = txtCpf.Text;
                _funcionario.Cidade = txtCidade.Text;
                _funcionario.CargaHoraria = txtCarga.Text;

            if (double.TryParse(txtSalario.Text, out double salario))
                _funcionario.Salario = salario;

            if (dpData.SelectedDate != null)
            {
                _funcionario.DataNasc = (DateTime)dpData.SelectedDate;
            }

            SaveData();
            CloseFormVerify();   
                               
        }
        private bool Validate()
        {
            return true;
        }
        private void SaveData()
        {
            try
            {
                if (Validate())
                {
                    var dao = new FuncionarioDAO();
                    var text = "Atualizado";

                    if(_funcionario.Id == 0)
                    {
                        dao.Insert(_funcionario);
                        text = "Adicionado";
                    }
                    else
                    {
                        dao.Update(_funcionario);
                        MessageBox.Show($"O funcionário foi {text} com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                        CloseFormVerify();

                    }
                }

            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Não executado", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void FillForm()
        {
            try
            {

                var dao = new FuncionarioDAO();
                _funcionario = dao.GetById(_id);

                txtNome.Text = _funcionario.Nome;
                txtTelefone.Text = _funcionario.Telefone;
                txtSetor.Text = _funcionario.Setor;
                 txtRg.Text = _funcionario.Rg;
                txtFuncao.Text = _funcionario.Funcao;
                txtEstCivi.Text = _funcionario.EstadoCivil;
                 txtEstado.Text = _funcionario.Estado;
                txtCpf.Text = _funcionario.Cpf;
                 txtCidade.Text = _funcionario.Cidade;
                txtCarga.Text = _funcionario.CargaHoraria;
                // _funcionario.CargaHoraria = txtCarga.Text;
                txtSalario.Text = _funcionario.Salario.ToString();
                dpData.Text = _funcionario.DataNasc.ToString();

            }
            catch  (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }
        private void CloseFormVerify()
        {
            if (_funcionario.Id == 0)
            {
                var result = MessageBox.Show("Deseja continuar adicionando funcionários?", "Continuar?", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                    this.Close();
                else
                    ClearInputs();
            }else
                this.Close();
        }
        private void ClearInputs()
        {
            txtNome.Text = "";
            txtTelefone.Text = "";
            txtSetor.Text = "";
            txtRg.Text = "";
            txtFuncao.Text = "";
            txtEstCivi.Text = "";
            txtEstado.Text = "";
            txtCpf.Text = "";
            txtCidade.Text = "";
            txtCarga.Text = "";
            txtSalario.Text = "" ;
            dpData.Text = "";
        }

        private void btnConsulta_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new ListFuncionario();
            newWindow.Show();
            Close();
        }
    }
}
