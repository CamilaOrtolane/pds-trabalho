﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TelasWpf.Models;

namespace TelasWpf.TelasCadastro
{
    /// <summary>
    /// Lógica interna para cadastrarMovel.xaml
    /// </summary>
    public partial class cadastrarMovel : Window
    {
        private int _id;

        private  Movel _movel;
        public cadastrarMovel()
        {
            InitializeComponent();
            Loaded += CadastrarMovel_Loaded;
        }

        public cadastrarMovel(int id)
        {
            _id = id;
            InitializeComponent();
            Loaded += CadastrarMovel_Loaded;
        }
        private void CadastrarMovel_Loaded(object sender, RoutedEventArgs e)
        {
            _movel = new Movel();

            if (_id > 0)
            {
                FillForm();
            }

        }

        private void btnVoltar_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new MenuPrincipal();
            newWindow.Show();
            Close();
        }

        private void btnSalvar_Click(object sender, RoutedEventArgs e)
        {
            _movel.Nome = txtNomeMovel.Text;
            _movel.Material = txtMaterial.Text;
            _movel.Descricao = txtDescriMovel.Text;
            _movel.Cor = txtCor.Text;
            
            if (double.TryParse(txtValorMovel.Text, out double valorM))
                _movel.ValorTotal = valorM;
            if (double.TryParse(txtPesoMovel.Text, out double pesoM))
                _movel.Peso = pesoM;
            if (double.TryParse(txtCompriMovel.Text, out double compriM))
                _movel.Comprimento = compriM;
            if (double.TryParse(txtAltura.Text, out double alturaM))
                _movel.Altura = alturaM;
            if (double.TryParse(txtLargura.Text, out double larguraM))
                _movel.Largura = larguraM;
            if (double.TryParse(txtCustoMovel.Text, out double custoM))
                _movel.ValorCusto = custoM;

            SaveData();
            CloseFormVerify();
        }
        private bool Validate()
        {
            return true;
        }
        private void SaveData()
        {
            try
            {
                if (Validate())
                {
                    var dao = new MovelDAO();
                    var text = "Atualizado";

                    if (_movel.Id == 0)
                    {
                        dao.Insert(_movel);
                        text = "Adicionado";
                    }
                    else
                    {
                        dao.Update(_movel);
                        MessageBox.Show($"O móvel foi {text} com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                        CloseFormVerify();

                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Não executado", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void FillForm()
        {
            try
            {

                var dao = new MovelDAO();
                _movel = dao.GetById(_id);


                 txtNomeMovel.Text = _movel.Nome;
                 txtMaterial.Text = _movel.Material;
                 txtDescriMovel.Text = _movel.Descricao;
                 txtPesoMovel.Text = _movel.Peso.ToString();
                 txtCompriMovel.Text = _movel.Comprimento.ToString();
                 txtCor.Text = _movel.Cor;
                 txtAltura.Text = _movel.Altura.ToString();
                 txtLargura.Text = _movel.Largura.ToString();
                 txtCustoMovel.Text = _movel.ValorCusto.ToString();
                 txtValorMovel.Text = _movel.ValorTotal.ToString();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }
        private void CloseFormVerify()
        {
            if (_movel.Id == 0)
            {
                var result = MessageBox.Show("Deseja continuar adicionando funcionários?", "Continuar?", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                    this.Close();
                else
                    ClearInputs();
            }
            else
                this.Close();
        }
        private void ClearInputs()
        {
            txtNomeMovel.Text = "";
            txtMaterial.Text = "";
            txtDescriMovel.Text = "";
            txtPesoMovel.Text = "";
            txtCompriMovel.Text = "";
            txtCor.Text = "";
            txtAltura.Text = "";
            txtLargura.Text = "";
            txtCustoMovel.Text = "";
            txtValorMovel.Text = "";
        }


        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnConsulta_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new listMovel();
            newWindow.Show();
            Close();
        }
    }
}
