﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.TextFormatting;
using System.Windows.Shapes;
using TelasWpf.Models;
using TelasWpf.Database;
using TelasWpf.Helpers;
using TelasWpf.interfaces;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Common;

namespace TelasWpf.TelasCadastro
{
    /// <summary>
    /// Lógica interna para cadastrarFornecedor.xaml
    /// </summary>
    public partial class cadastrarFornecedor : Window
    {
        private int _id;

        private Fornecedor _fornecedor;
        public cadastrarFornecedor()
        {
            InitializeComponent();
            Loaded += CadastrarFornecedor_Loaded;
        }
        public cadastrarFornecedor(int id)
        {
            _id = id;
            InitializeComponent();
            Loaded += CadastrarFornecedor_Loaded;
        }


        private void CadastrarFornecedor_Loaded(object sender, RoutedEventArgs e)
        {
            _fornecedor = new Fornecedor();

            if (_id > 0)
            {
                FillForm();
            }
        }

        private void btnVoltar_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new MenuPrincipal();
            newWindow.Show();
            Close();
        }

        private void btnSalvar_Click(object sender, RoutedEventArgs e)
        {
            _fornecedor.NomeFantasia = txtNomForn.Text;
            _fornecedor.RazaoSocial = txtRazaoSocial.Text;
            _fornecedor.Cnpj = txtCnpjForn.Text;
            _fornecedor.Telefone = txtTelefone.Text;
            _fornecedor.Endereco = txtEnd.Text;
            _fornecedor.Estado = txtEstadoForn.Text;
            _fornecedor.Cidade = txtCidadeForn.Text;

            SaveData();
            CloseFormVerify();

        }

        private bool Validate()
        {
            return true;
        }
        private void SaveData()
        {
            try
            {
                if (Validate())
                {
                    var dao = new FornecedorDAO();
                    var text = "Atualizado";

                    if (_fornecedor.Id == 0)
                    {
                        dao.Insert(_fornecedor);
                        text = "Adicionado";
                    }
                    else
                    {
                        dao.Update(_fornecedor);
                        MessageBox.Show($"O fornecedor foi {text} com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                        CloseFormVerify();

                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Não executado", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void FillForm()
        {
            try
            {

                var dao = new FornecedorDAO();
                _fornecedor = dao.GetById(_id);

                 txtNomForn.Text = _fornecedor.NomeFantasia;
                 txtRazaoSocial.Text = _fornecedor.RazaoSocial;
                 txtCnpjForn.Text = _fornecedor.Cnpj;
                 txtTelefone.Text = _fornecedor.Telefone;
                 txtEnd.Text = _fornecedor.Endereco;
                 txtCidadeForn.Text = _fornecedor.Cidade;
                 txtEstadoForn.Text = _fornecedor.Estado;

               

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }
        private void CloseFormVerify()
        {
            if (_fornecedor.Id == 0)
            {
                var result = MessageBox.Show("Deseja continuar adicionando?", "Continuar?", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                    this.Close();
                else
                    ClearInputs();
            }
            else
                this.Close();
        }
        private void ClearInputs()
        {
            txtNomForn.Text = "";
            txtCnpjForn.Text = "";
            txtRazaoSocial.Text = "";
            txtEstadoForn.Text = "";
            txtCidadeForn.Text = "";
            txtTelefone.Text = "";

        }


        private void btnConsultar_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new ListFornecedor();
            newWindow.Show();
            Close();
        }

        private void btnListar_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new ListFornecedor();
            newWindow.Show();
            Close();
        }
    }
}
