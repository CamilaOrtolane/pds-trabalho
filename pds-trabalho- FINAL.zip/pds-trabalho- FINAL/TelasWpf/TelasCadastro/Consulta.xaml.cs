﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TelasWpf.TelasCadastro
{
    /// <summary>
    /// Lógica interna para Consulta.xaml
    /// </summary>
    public partial class Consulta : Window
    {
        public Consulta()
        {
            InitializeComponent();
        }

        private void btnMovel_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new listMovel();
            newWindow.Show();
            Close();
        }

        private void btnVenda_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new ListVenda();
            newWindow.Show();
            Close();
        }

        private void btnServico_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new ListServico();
            newWindow.Show();
            Close();
        }


        private void btnFornecedor_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new ListFornecedor();
            newWindow.Show();
            Close();
        }

        private void btnCompra_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new ListCompra();
            newWindow.Show();
            Close();
        }

       

        private void btnFuncionario_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new ListFuncionario();
            newWindow.Show();
            Close();
        }

        private void btnClientes_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new ListCliente();
            newWindow.Show();
            Close();
        }
    }
}
