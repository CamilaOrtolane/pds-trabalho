﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TelasWpf.Models;
using TelasWpf.Helpers;
using static System.Net.Mime.MediaTypeNames;
using System.Xml.Linq;
using MySql.Data.MySqlClient;
using System.Windows.Markup;


namespace TelasWpf.TelasCadastro
{
    /// <summary>
    /// Lógica interna para cadastrarServico.xaml
    /// </summary>
    public partial class cadastrarServico : Window
    {
        private int _id;

        private Servico _servico;
        public cadastrarServico()
        {
            InitializeComponent();
            Loaded += CadastrarServico_Loaded;
        }
        public cadastrarServico(int id)
        {
            _id = id;
            InitializeComponent();
            Loaded += CadastrarServico_Loaded;
        }

        private void CadastrarServico_Loaded(object sender, RoutedEventArgs e)
        {
            _servico = new Servico();

            if (_id > 0)
            {
                FillForm();
            }
        }

        private void btnVoltar_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new MenuPrincipal();
            newWindow.Show();
            Close();
        }

        private void btnSalvar_CLick(object sender, RoutedEventArgs e)
        {
            _servico.Nome = txtNome.Text;
            _servico.Descricao = txtDescricao.Text;
            SaveData();
            CloseFormVerify();
        }
        private bool Validate()
        {
            return true;
        }
        private void SaveData()
        {
            try
            {
                if (Validate())
                {
                    var dao = new ServicoDAO();
                    var text = "Atualizado";

                    if (_servico.Id == 0)
                    {
                        dao.Insert(_servico);
                        text = "Adicionado";
                    }
                    else
                    {
                        dao.Update(_servico);
                        MessageBox.Show($"O funcionário foi {text} com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                        CloseFormVerify();

                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Não executado", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void FillForm()
        {
            try
            {

                var dao = new ServicoDAO();
                _servico = dao.GetById(_id);
                
                txtNome.Text = _servico.Nome;
                txtDescricao.Text = _servico.Descricao;



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }
        private void CloseFormVerify()
        {
            if (_servico.Id == 0)
            {
                var result = MessageBox.Show("Deseja continuar adicionando?", "Continuar?", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                    this.Close();
                else
                    ClearInputs();
            }
            else
                this.Close();
        }
        private void ClearInputs()
        {
            txtNome.Text = "";
            txtDescricao.Text = "";
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnConsulta_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new ListServico();
            newWindow.Show();
            Close();
        }
    }
}
