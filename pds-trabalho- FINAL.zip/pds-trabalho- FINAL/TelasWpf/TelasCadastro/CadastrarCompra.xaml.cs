﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TelasWpf.Models;

namespace TelasWpf.TelasCadastro
{
    /// <summary>
    /// Lógica interna para CadastrarCompra.xaml
    /// </summary>
    public partial class CadastrarCompra : Window
    {
        private int _id;

        private Compra _compra;

        private List<Funcionario> funcionarios;

        //private List<Fornecedor> fornecedores;

        public CadastrarCompra()
        {
           InitializeComponent();
            Loaded += CadastrarCompra_Loaded;

        }
        public CadastrarCompra(int id)
        {
            _id = id;
            InitializeComponent();
            Loaded += CadastrarCompra_Loaded;

        }
        private void CadastrarCompra_Loaded(object sender, RoutedEventArgs e)
        {
            CarregarDados();
        }

        private void CarregarDados()
        {
            try
            {
                var movDao = new MovelDAO();
                cbProduto.ItemsSource = movDao.List();

                var funcDao = new FuncionarioDAO();
                cbFuncionario.ItemsSource = funcDao.List();

                var fornDao = new FornecedorDAO();
                cbFornecedor.ItemsSource = fornDao.List();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnVoltar_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new MenuPrincipal();
            newWindow.Show();
            Close();
        }

        private void btnSalvar_Click(object sender, RoutedEventArgs e)
            {


                if(cbProduto.SelectedItem != null)
                {
                    _compra.Produto = (Movel)cbProduto.SelectedItem;
                }

                _compra.Codigo = txtCodProd.Text;
                _compra.Valor = double.Parse(txtValor.Text);
                

                //com.CodigoProduto = Convert.ToInt32(txtCodProd.Text);

                if (cbFuncionario.SelectedItem != null)
                {
                    _compra.Funcionario = (Funcionario)cbFuncionario.SelectedItem;
                    //com.Funcionario = cbFuncionario.SelectedItem as Funcionario;
                }
                if (cbFornecedor.SelectedItem != null)
                {
                    _compra.Fornecedor = (Fornecedor)cbFornecedor.SelectedItem;
                }


                
        }
        private bool Validate()
        {
            return true;
        }
        private void SaveData()
        {
            try
            {
                if (Validate())
                {
                    var dao = new CompraDAO();
                    var text = "Atualizado";

                    if (_compra.Id == 0)
                    {
                        dao.Insert(_compra);
                        text = "Adicionado";
                    }
                    else
                    {
                        dao.Update(_compra);
                        MessageBox.Show($"O funcionário foi {text} com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                        CloseFormVerify();

                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Não executado", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void FillForm()
        {
            try
            {

                var dao = new CompraDAO();
                _compra = dao.GetById(_id);

                cbProduto.Text = Convert.ToString(_compra.Produto);
                txtCodProd.Text = _compra.Codigo;
                txtValor.Text = Convert.ToString( _compra.Valor);
                cbFornecedor.Text = Convert.ToString(_compra.Fornecedor);
                cbFuncionario.Text = Convert.ToString(_compra.Funcionario);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }
        private void CloseFormVerify()
        {
            if (_compra.Id == 0)
            {
                var result = MessageBox.Show("Deseja continuar adicionando?", "Continuar?", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                    this.Close();
                else
                    ClearInputs();
            }
            else
                this.Close();
        }
        private void ClearInputs()
        {
            cbFornecedor.SelectedIndex = 0;
            txtValor.Text = "";
            txtCodProd.Text = "";
            cbFuncionario.SelectedIndex = 0;
            dpData.Text = "";
            cbProduto.SelectedIndex = 0;
        }

        private void cbFuncionario_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
        }

        private void btnConsulta_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new ListCompra();
            newWindow.Show();
            Close();
        }

        private void cbFornecedor_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void cbFuncionario_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }

        private void cbProduto_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }

        private void cbProduto_SelectionChanged_2(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
