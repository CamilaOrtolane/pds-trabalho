﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TelasWpf.Models;
using TelasWpf.Database;
using TelasWpf.Helpers;
using TelasWpf.interfaces;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Common;

namespace TelasWpf.TelasCadastro
{
    /// <summary>
    /// Lógica interna para cadastroCliente.xaml
    /// </summary>
    public partial class cadastroCliente : Window
    {
        private int _id;
        private Cliente _cliente;
        public cadastroCliente()
        {
            InitializeComponent();
            Loaded += CadastroCliente_Loaded; 
            
        }
        public cadastroCliente(int id)
        {
            _id = id;   
            InitializeComponent();
            Loaded += CadastroCliente_Loaded;

        }

        private void CadastroCliente_Loaded(object sender, RoutedEventArgs e)
        {
            _cliente = new Cliente();

            if (_id > 0)
            {
                FillForm();
            }
        }

        private void btnVoltar_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new MenuPrincipal();
            newWindow.Show();
            Close();
        }

        private void btnSalvar_Click(object sender, RoutedEventArgs e)
        {
            
            _cliente.NomeCliente = txtNomCli.Text;
            _cliente.Cpf = txtCpf.Text;
            _cliente.Rg = txtRg.Text;
            _cliente.EstadoCivil = txtEstadoCivil.Text;
            _cliente.Estado = txtEstado.Text;
            _cliente.Cidade = txtCidade.Text;
            _cliente.Endereco = txtEndereco.Text;
            _cliente.Telefone = txtTelefone.Text;
            _cliente.Profissao = txtProfissao.Text;

            if (dpData.SelectedDate != null)
            {
                _cliente.DataNasc = (DateTime)dpData.SelectedDate;
            }

            SaveData();
            CloseFormVerify();

        }
        private bool Validate()
        {
            return true;
        }
        private void SaveData()
        {
            try
            {
                if (Validate())
                {
                    var dao = new ClienteDAO();
                    var text = "Atualizado";

                    if (_cliente.Id == 0)
                    {
                        dao.Insert(_cliente);
                        text = "Adicionado";
                    }
                    else
                    {
                        dao.Update(_cliente);
                        MessageBox.Show($"O cliente foi {text} com sucesso!", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
                        CloseFormVerify();

                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Não executado", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void FillForm()
        {
            try
            {
                var dao = new ClienteDAO();
                _cliente = dao.GetById(_id);

                 txtNomCli.Text = _cliente.NomeCliente;
                 txtCpf.Text = _cliente.Cpf;
                 txtRg.Text = _cliente.Rg;
                 txtEstadoCivil.Text = _cliente.EstadoCivil;
                 dpData.Text = _cliente.DataNasc.ToString();
                 txtTelefone.Text = _cliente.Telefone;
                 txtProfissao.Text = _cliente.Profissao;
                 txtCidade.Text = _cliente.Cidade;
                 txtEstado.Text = _cliente.Estado;
                 txtEndereco.Text = _cliente.Endereco;
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exceção", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }
        private void CloseFormVerify()
        {
            if (_cliente.Id == 0)
            {
                var result = MessageBox.Show("Deseja continuar adicionando os clientes?", "Continuar?", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.No)
                    this.Close();
                else
                    ClearInputs();
            }
            else
                this.Close();
        }
        private void ClearInputs()
        {
            txtTelefone.Text = "";
            txtRg.Text = "";
            txtProfissao.Text = "";
            txtNomCli.Text = "";
            txtEstadoCivil.Text = "";
            txtEstado.Text = "";
            txtEndereco.Text = "";
            dpData.Text = "";
            txtCpf.Text = "";
            txtCidade.Text = "";
        }

        private void btnConsulta_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new ListCliente();
            newWindow.Show();
            Close();
        }
    }
}
