﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TelasWpf.Database;
using TelasWpf.interfaces;
using TelasWpf.Helpers;
using TelasWpf.TelasCadastro;
using MySql.Data.MySqlClient;

namespace TelasWpf.Models
{
    internal class FornecedorDAO : IDAO<Fornecedor>
    {
        private static Conexao conn;
        
        public FornecedorDAO() 
        {
            conn = new Conexao();
        }  
        public void Delete(Fornecedor t)
        {
            try
            {
                var query = conn.Query();
                query.CommandText = "DELETE FROM Fornecedor WHERE id_for = @id ";
                query.Parameters.AddWithValue("@id", t.Id);

                var resultado = query.ExecuteNonQuery();
                if (resultado == 0)
                {
                    throw new Exception("O registro não foi removido. Verifique e tente novamente");

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
        }

        public Fornecedor GetById(int id)
        {
            var query = conn.Query();
            query.CommandText = "SELECT * FROM fornecedor WHERE id_for = @id";

            query.Parameters.AddWithValue("@id", id);

            MySqlDataReader reader = query.ExecuteReader();

            if (!reader.HasRows)
                throw new Exception("Nenhum registro foi encontrado!");

            var fornecedor = new Fornecedor();

            while (reader.Read())
            {

                fornecedor.Id = reader.GetInt32("id_for");
                fornecedor.NomeFantasia = DAOhelpers.GetString(reader, "nome_fantasia_for");
                fornecedor.RazaoSocial = DAOhelpers.GetString(reader, "razao_social_for");
                fornecedor.Cnpj = DAOhelpers.GetString(reader, "cnpj_for");
                fornecedor.Telefone = DAOhelpers.GetString(reader, "telefone_for");
                fornecedor.Endereco = DAOhelpers.GetString(reader, "endereco_for");
                fornecedor.Cidade = DAOhelpers.GetString(reader, "cidade_for");
                fornecedor.Estado = DAOhelpers.GetString(reader, "estado_for");

            }
            return fornecedor;
        }

        public void Insert(Fornecedor t)
        {
            try
            {
                var query = conn.Query();
                query.CommandText = "INSERT INTO fornecedor (nome_fantasia_for, razao_social_for, cnpj_for,telefone_for, endereco_for, cidade_for, estado_for) VALUES (@nome_fantasia, @razao_social, @cnpj, @telefone, @endereco, @cidade, @estado)";
                query.Parameters.AddWithValue("@nome_fantasia", t.NomeFantasia);
                query.Parameters.AddWithValue("@razao_social", t.RazaoSocial);
                query.Parameters.AddWithValue("@cnpj", t.Cnpj);
                query.Parameters.AddWithValue("@telefone", t.Telefone);
                query.Parameters.AddWithValue("@endereco", t.Endereco);
                query.Parameters.AddWithValue("@cidade", t.Cidade);
                query.Parameters.AddWithValue("@estado", t.Estado);
                

                var result = query.ExecuteNonQuery();

                if (result == 0)
                    throw new Exception("O registo não foi inserido. Verifique e tente novamente");


            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conn.Close();
            }

        }

        public List<Fornecedor> List()
        {
            try
            {
                List<Fornecedor> list = new List<Fornecedor>();

                var query = conn.Query();
                query.CommandText = "SELECT * FROM fornecedor";

                MySqlDataReader reader = query.ExecuteReader();

                while (reader.Read())
                {
                    list.Add(new Fornecedor()
                    {
                        Id = reader.GetInt32("id_for"),
                        NomeFantasia = DAOhelpers.GetString(reader, "nome_fantasia_for"),
                        RazaoSocial = DAOhelpers.GetString(reader, "razao_social_for"),
                        Cnpj = DAOhelpers.GetString(reader, "cnpj_for"),
                        Telefone = DAOhelpers.GetString(reader, "telefone_for"),
                        Endereco = DAOhelpers.GetString(reader, "endereco_for"),
                        Cidade = DAOhelpers.GetString(reader, "cidade_for"),
                        Estado = DAOhelpers.GetString(reader, "estado_for")
                    });
                }

                return list;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conn.Close();
            }
        }


        public void Update(Fornecedor t)
        {
            try
            {

                var query = conn.Query();
                query.CommandText = "UPDATE fornecedor SET nome_fantasia_for = @nome, razao_social_for = @razaoSocial, cnpj_for = @cnpj, telefone_for = @telefone, endereco_for = @endereco,cidade_for = @cidade, estado_for = @estado where id_for = @id ";

                query.Parameters.AddWithValue("@nome", t.NomeFantasia);
                query.Parameters.AddWithValue("@razaoSocial", t.RazaoSocial);
                query.Parameters.AddWithValue("@cnpj", t.Cnpj);
                query.Parameters.AddWithValue("@telefone", t.Telefone);
                query.Parameters.AddWithValue("@endereco", t.Endereco);
                query.Parameters.AddWithValue("@cidade", t.Cidade);
                query.Parameters.AddWithValue("@estado", t.Estado);
                query.Parameters.AddWithValue("@id", t.Id);

                var result = query.ExecuteNonQuery();

                if (result == 0)
                    throw new Exception("Atualização do registro não foi realizada.");

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conn.Close();
            }
        }

        void IDAO<Fornecedor>.Insert(Fornecedor t)
        {
            throw new NotImplementedException();
        }
    }
}
