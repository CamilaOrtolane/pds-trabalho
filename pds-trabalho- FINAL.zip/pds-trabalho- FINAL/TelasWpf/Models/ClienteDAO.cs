﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TelasWpf.interfaces;
using TelasWpf.Database;
using TelasWpf.Helpers;
using MySql.Data.MySqlClient;
using System.Windows.Input;

namespace TelasWpf.Models
{
    class ClienteDAO : IDAO<Cliente>
    {
        private static Conexao conn;

        public ClienteDAO()
        {
            conn = new Conexao();
        }

        public void Delete(TelasWpf.Models.Cliente t)
        {
            try
            {
                var query = conn.Query();
                query.CommandText = "DELETE FROM Cliente WHERE id_cli = @id ";
                query.Parameters.AddWithValue("@id", t.Id);

                var resultado = query.ExecuteNonQuery();
                if (resultado == 0)
                {
                    throw new Exception("O registro não foi removido. Verifique e tente novamente");

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
        }
        public Cliente GetById(int id)
        {
            var query = conn.Query();
            query.CommandText = "SELECT * FROM cliente WHERE id_cli = @id";

            query.Parameters.AddWithValue("@id", id);

            MySqlDataReader reader = query.ExecuteReader();

            if (!reader.HasRows)
                throw new Exception("Nenhum registro foi encontrado!");

            var cliente = new Cliente();

            while (reader.Read())
            {
                cliente.Id = reader.GetInt32("id_cli");
                cliente.NomeCliente = DAOhelpers.GetString(reader, "nome_cli");
                cliente.Cpf = DAOhelpers.GetString(reader, "cpf_cli");
                cliente.Rg = DAOhelpers.GetString(reader, "rg_cli");
                cliente.EstadoCivil = DAOhelpers.GetString(reader, "estado_civil_cli");
                cliente.DataNasc = reader.GetDateTime("data_nasc_cli");
                cliente.Telefone = DAOhelpers.GetString(reader, "telefone_cli");
                cliente.Profissao = DAOhelpers.GetString(reader, "profissao_cli");
                cliente.Cidade = DAOhelpers.GetString(reader, "cidade_cli");
                cliente.Estado = DAOhelpers.GetString(reader, "estado_cli");
                cliente.Endereco = DAOhelpers.GetString(reader, "endereco_cli");

            }
            return cliente;
        }
        public void Insert(Cliente t)
        {
            try
            {
                var query = conn.Query();
                query.CommandText = "INSERT INTO Cliente (nome_cli, cpf_cli, rg_cli, estado_civil_cli, data_nasc_cli, telefone_cli, profissao_cli, cidade_cli, estado_cli, endereco_cli) " +
                    "VALUES (@nome, @cpf, @rg, @estado_civil,@data, @telefone, @profissao, @cidade, @estado, @endereco)";
                query.Parameters.AddWithValue("@nome", t.NomeCliente);
                query.Parameters.AddWithValue("@cpf", t.Cpf);
                query.Parameters.AddWithValue("@rg", t.Rg);
                query.Parameters.AddWithValue("@estado_civil", t.EstadoCivil);
                query.Parameters.AddWithValue("@data", t.DataNasc.ToString("yyyy-MM-dd"));
                query.Parameters.AddWithValue("@telefone", t.Telefone);
                query.Parameters.AddWithValue("@profissao", t.Profissao);
                query.Parameters.AddWithValue("@cidade", t.Cidade);
                query.Parameters.AddWithValue("@estado", t.Estado);
                query.Parameters.AddWithValue("@endereco", t.Endereco);

                var resultado = query.ExecuteNonQuery();
                if(resultado == 0)
                {
                    throw new Exception("O registro não foi inserido. Verifique e tente novamente");

                }

            } 
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
        }
        public List<Cliente> List()
        {
            try
            {

                List<Cliente> list = new List<Cliente>();

                var query = conn.Query();
                query.CommandText = "SELECT * FROM cliente";

                MySqlDataReader reader = query.ExecuteReader();

                while (reader.Read())
                {
                    list.Add(new Cliente()
                    {
                        Id = reader.GetInt32("id_cli"),
                        NomeCliente = DAOhelpers.GetString(reader, "nome_cli"),
                        Cpf = DAOhelpers.GetString(reader, "cpf_cli"),
                        Rg = DAOhelpers.GetString(reader, "rg_cli"),
                        EstadoCivil = DAOhelpers.GetString(reader, "estado_civil_cli"),
                        DataNasc = reader.GetDateTime("data_nasc_cli"),
                        Telefone = DAOhelpers.GetString(reader, "telefone_cli"),
                        Profissao = DAOhelpers.GetString(reader, "profissao_cli"),
                        Cidade = DAOhelpers.GetString(reader, "cidade_cli"),
                        Estado = DAOhelpers.GetString(reader, "estado_cli"),
                        Endereco = DAOhelpers.GetString(reader, "endereco_cli")
                       
                    });
                }
                return list;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
        }
        public void Update(Cliente t)
        {
            try
            {
                var query = conn.Query();
                query.CommandText = "UPDATE cliente SET nome_cli = @nome,cpf_cli = @cpf, rg_cli = @rg, estado_civil_cli = @estado_civil, data_nasc_cli = @data,    " +
                    "telefone_cli = @telefone, profissao_cli = @profissao, cidade_cli = @cidade, estado_cli = @estado, endereco_cli = @endereco where id_cli = @id";

                query.Parameters.AddWithValue("@nome", t.NomeCliente);
                query.Parameters.AddWithValue("@cpf", t.Cpf);
                query.Parameters.AddWithValue("@rg", t.Rg);
                query.Parameters.AddWithValue("@estado_civil", t.EstadoCivil);
                query.Parameters.AddWithValue("@data", t.DataNasc.ToString("yyyy-MM-dd"));
                query.Parameters.AddWithValue("@telefone", t.Telefone);
                query.Parameters.AddWithValue("@profissao", t.Profissao);
                query.Parameters.AddWithValue("@cidade", t.Cidade);
                query.Parameters.AddWithValue("@estado", t.Estado);
                query.Parameters.AddWithValue("@endereco", t.Endereco);
                query.Parameters.AddWithValue("@id", t.Id);

                var result = query.ExecuteNonQuery();

                if (result == 0)
                    throw new Exception("Atualização do registro não foi realizada.");

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conn.Close();
            }
        }
        
        void IDAO<Cliente>.Insert(Cliente t) 
        {
            throw new NotImplementedException();
        }

    }
}
