﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using TelasWpf.interfaces;
using TelasWpf.Helpers;
using TelasWpf.Database;
using System.Runtime.ConstrainedExecution;
using System.Windows.Media.Media3D;

namespace TelasWpf.Models
{
    internal class MovelDAO : IDAO<Movel>
    {
        private static Conexao conn;

        public MovelDAO()
        {
            conn = new Conexao();
        }
        public void Delete(Movel t)
        {
            try
            {
                var query = conn.Query();
                query.CommandText = "DELETE FROM Movel WHERE id_mov = @id ";
                query.Parameters.AddWithValue("@id", t.Id);

                var resultado = query.ExecuteNonQuery();
                if (resultado == 0)
                {
                    throw new Exception("O registro não foi removido. Verifique e tente novamente");

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
        }

        public Movel GetById(int id)
        {
            var query = conn.Query();
            query.CommandText = "SELECT * FROM movel WHERE id_mov = @id";

            query.Parameters.AddWithValue("@id", id);

            MySqlDataReader reader = query.ExecuteReader();

            if (!reader.HasRows)
                throw new Exception("Nenhum registro foi encontrado!");

            var movel = new Movel();

            while (reader.Read())
            {
                movel.Id = reader.GetInt32("id_mov");
                movel.Nome = DAOhelpers.GetString(reader, "nome_mov");
                movel.Material = DAOhelpers.GetString(reader, "materia_mov");
                movel.Descricao = DAOhelpers.GetString(reader, "descricao_mov");
                movel.Peso = DAOhelpers.GetDouble(reader, "peso_mov");
                movel.Comprimento = DAOhelpers.GetDouble(reader, "comprimento_mov");
                movel.Cor = DAOhelpers.GetString(reader, "cor_mov");
                movel.Altura = DAOhelpers.GetDouble(reader, "altura_mov");
                movel.Largura = DAOhelpers.GetDouble(reader, "largura_mov");
                movel.ValorCusto = DAOhelpers.GetDouble(reader, "valor_custo_mov");
                movel.ValorTotal = DAOhelpers.GetDouble(reader, "valor_venda_mov");


            }
            return movel;
        }

        public void Insert(Movel t)
        {
            try
            {
                var query = conn.Query();
                query.CommandText = "INSERT INTO Movel (nome_mov, materia_mov, descricao_mov, comprimento_mov, cor_mov, altura_mov, valor_custo_mov, valor_venda_mov) VALUES (@nome_mov, @materia_mov, @descricao_mov, @comprimento_mov, @cor_mov, @altura_mov, @valor_custo_mov, @valor_venda_mov)";
                query.Parameters.AddWithValue("@nome_mov", t.Nome);
                query.Parameters.AddWithValue("@materia_mov", t.Material);
                query.Parameters.AddWithValue("@descricao_mov", t.Descricao);
                query.Parameters.AddWithValue("@comprimento_mov", t.Comprimento);
                query.Parameters.AddWithValue("@cor_mov", t.Cor);
                query.Parameters.AddWithValue("@altura_mov", t.Altura);
                query.Parameters.AddWithValue("@largura_mov", t.Largura);
                query.Parameters.AddWithValue("@valor_custo_mov", t.ValorCusto);
                query.Parameters.AddWithValue("@valor_venda_mov", t.ValorTotal);

                var result = query.ExecuteNonQuery();

                if (result == 0)
                    throw new Exception("O registo não foi inserido. Verifique e tente novamente");


            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conn.Close();
            }

        }

        public List<Movel> List()
        {
            try
            {
                List<Movel> list = new List<Movel>();

                var query = conn.Query();
                query.CommandText = "SELECT * FROM Movel";

                MySqlDataReader reader = query.ExecuteReader();

                while (reader.Read())
                {
                    list.Add(new Movel()
                    {
                        Id = reader.GetInt32("id_mov"),
                        Nome = DAOhelpers.GetString(reader, "nome_mov"),
                        Material = DAOhelpers.GetString(reader, "materia_mov"),
                        Descricao = DAOhelpers.GetString(reader, "descricao_mov"),
                        Peso = DAOhelpers.GetDouble(reader, "peso_mov"),
                        Comprimento = DAOhelpers.GetDouble(reader, "comprimento_mov"),
                        Cor = DAOhelpers.GetString(reader, "cor_mov"),
                        Altura = DAOhelpers.GetDouble(reader, "altura_mov"),
                        Largura = DAOhelpers.GetDouble(reader, "largura_mov"),
                        ValorCusto = DAOhelpers.GetDouble(reader, "valor_custo_mov"),
                        ValorTotal = DAOhelpers.GetDouble(reader, "valor_venda_mov")

                    });
                }

                return list;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conn.Close();
            }
        }


        public void Update(Movel t)
        {
            try
            {

                var query = conn.Query();
                query.CommandText = "UPDATE movel SET nome_mov = @nome, material_mov = @material, altura_mov = @altura, comprimento = @comprimento_mov, " +
                    "cor_mov = @cor, peso_mov = @peso, largura_mov = @largura, descricao_mov = @descricao, valor_custo_mov = @valorcusto, valor_venda_mov = @valortotal where id_mov = @id";

                query.Parameters.AddWithValue("@nome", t.Nome);
                query.Parameters.AddWithValue("@material", t.Material);
                query.Parameters.AddWithValue("@altura", t.Altura);
                query.Parameters.AddWithValue("@comprimento", t.Comprimento);
                query.Parameters.AddWithValue("@cor", t.Cor);
                query.Parameters.AddWithValue("@peso", t.Peso);
                query.Parameters.AddWithValue("@largura", t.Largura);
                query.Parameters.AddWithValue("@descricao", t.Descricao);
                query.Parameters.AddWithValue("@valorcusto", t.ValorCusto);
                query.Parameters.AddWithValue("@valortotal", t.ValorTotal);
                query.Parameters.AddWithValue("@id", t.Id);

                var result = query.ExecuteNonQuery();

                if (result == 0)
                    throw new Exception("Atualização do registro não foi realizada.");

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conn.Close();
            }
        }

        void IDAO<Movel>.Insert(Movel t)
        {
            throw new NotImplementedException();
        }
    }
}
